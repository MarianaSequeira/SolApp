package ua.pt.solapp.database.entities;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Mariana on 22/12/2018.
 */

@Entity
public class WeatherID {

    @PrimaryKey
    @NonNull
    @SerializedName("id")
    @Expose
    private String id;

    @SerializedName("owner")
    @Expose
    private String owner;

    @SerializedName("country")
    @Expose
    private String country;

    @SerializedName("descIdWeatherTypeEN")
    @Expose
    private String descIdWeatherTypeEN;

    @SerializedName("descIdWeatherTypePT")
    @Expose
    private String descIdWeatherTypePT;

    @SerializedName("idWeatherType")
    @Expose
    private int idWeatherType;



    // CONSTRUCTOR:
    public WeatherID(@NonNull String id, String owner, String country, String descIdWeatherTypeEN, String descIdWeatherTypePT, int idWeatherType) {
        this.id = id;
        this.owner = owner;
        this.country = country;
        this.descIdWeatherTypeEN = descIdWeatherTypeEN;
        this.descIdWeatherTypePT = descIdWeatherTypePT;
        this.idWeatherType = idWeatherType;
    }


    // GETTERS:
    @NonNull
    public String getId() { return id; }
    public String getOwner() { return owner; }
    public String getCountry() { return country; }
    public String getDescClassWindSpeedDailyEN() { return descIdWeatherTypeEN; }
    public String getDescClassWindSpeedDailyPT() { return descIdWeatherTypePT; }
    public int getClassWindSpeed() { return idWeatherType; }


    // SETTERS:
    public void setId(@NonNull String id) { this.id = id; }
    public void setOwner(String owner) { this.owner = owner; }
    public void setCountry(String country) { this.country = country; }
    public void setDescClassWindSpeedDailyEN(String descClassWindSpeedDailyEN) { this.descIdWeatherTypeEN = descIdWeatherTypeEN; }
    public void setDescClassWindSpeedDailyPT(String descClassWindSpeedDailyPT) { this.descIdWeatherTypePT = descIdWeatherTypePT; }
    public void setClassWindSpeed(int classWindSpeed) { this.idWeatherType = idWeatherType; }
}
