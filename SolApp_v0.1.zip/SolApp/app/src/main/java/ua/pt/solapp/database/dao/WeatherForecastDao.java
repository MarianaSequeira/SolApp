package ua.pt.solapp.database.dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.Date;

import ua.pt.solapp.database.entities.DistrictID;
import ua.pt.solapp.database.entities.WeatherForecast;
import ua.pt.solapp.database.entities.WeatherID;
import ua.pt.solapp.database.entities.WindSpeed;

import static android.arch.persistence.room.OnConflictStrategy.REPLACE;

/**
 * Created by Mariana on 22/12/2018.
 */

@Dao
interface WeatherForecastDao {


    @Insert(onConflict = REPLACE)
    void saveWeatherForecast(WeatherForecast weatherForecast);

    @Insert(onConflict = REPLACE)
    void saveDistrictID(DistrictID districtID);

    @Insert(onConflict = REPLACE)
    void saveWeatherID(WeatherID weatherID);

    @Insert(onConflict = REPLACE)
    void saveWindSpeed(WindSpeed windSpeed);


    @Query("SELECT * FROM weatherforecast WHERE globalIdLocal = :globalIdLocal AND lastRefresh > :lastRefreshMax LIMIT 1")
    LiveData<WeatherForecast> getWeatherForecastFromGlobalId(int globalIdLocal, Date lastRefreshMax);

    @Query("SELECT globalIdLocal FROM districtid WHERE local = :local")
    LiveData<WeatherForecast> getGlobalIdLocal(String local);

    @Query("SELECT descIdWeatherTypeEN, descIdWeatherTypePT FROM weatherid WHERE idWeatherType = :idWeatherType")
    LiveData<WeatherForecast> getWeatherType(int idWeatherType);

    @Query("SELECT descClassWindSpeedDailyEN, descClassWindSpeedDailyPT FROM windspeed WHERE classWindSpeed = :classWindSpeed")
    LiveData<WeatherForecast> getWindSpeed(int classWindSpeed);


}
