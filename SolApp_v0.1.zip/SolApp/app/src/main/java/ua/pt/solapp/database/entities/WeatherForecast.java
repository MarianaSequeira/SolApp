package ua.pt.solapp.database.entities;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Date;

/**
 * Created by Mariana on 22/12/2018.
 */

@Entity
public class WeatherForecast {

    @PrimaryKey
    @NonNull
    @SerializedName("id")
    @Expose
    private String id;

    @SerializedName("owner")
    @Expose
    private String owner;

    @SerializedName("country")
    @Expose
    private String country;

    @SerializedName("regNumber")
    @Expose
    private int regNumber;

    @SerializedName("precipitaProb")
    @Expose
    private String precipitaProb;

    @SerializedName("tMin")
    @Expose
    private String tMin;

    @SerializedName("tMax")
    @Expose
    private String tMax;

    @SerializedName("predWindDir")
    @Expose
    private String predWindDir;

    @SerializedName("idWeatherType")
    @Expose
    private int idWeatherType;

    @SerializedName("classWindSpeed")
    @Expose
    private int classWindSpeed;

    @SerializedName("longitude")
    @Expose
    private String longitude;

    @SerializedName("forecastDate")
    @Expose
    private String forecastDate;

    @SerializedName("latitude")
    @Expose
    private String latitude;

    @SerializedName("globalIdLocal")
    @Expose
    private int globalIdLocal;

    @SerializedName("dataUpdate")
    @Expose
    private String dataUpdate;

    private Date lastRefresh;


    //CONSTRUCTOR:
    public WeatherForecast(@NonNull String id, String owner, String country, int regNumber, String precipitaProb, String tMin, String tMax, String predWindDir, int idWeatherType, int classWindSpeed, String longitude, String forecastDate, String latitude, int globalIdLocal, String dataUpdate, Date lastRefresh) {
        this.id = id;
        this.owner = owner;
        this.country = country;
        this.regNumber = regNumber;
        this.precipitaProb = precipitaProb;
        this.tMin = tMin;
        this.tMax = tMax;
        this.predWindDir = predWindDir;
        this.idWeatherType = idWeatherType;
        this.classWindSpeed = classWindSpeed;
        this.longitude = longitude;
        this.forecastDate = forecastDate;
        this.latitude = latitude;
        this.globalIdLocal = globalIdLocal;
        this.dataUpdate = dataUpdate;
        this.lastRefresh = lastRefresh;
    }


    // GETTERS:
    @NonNull
    public String getId() { return id; }
    public String getOwner() { return owner; }
    public String getCountry() { return country; }
    public int getRegNumber() { return regNumber; }
    public String getPrecipitaProb() { return precipitaProb; }
    public String gettMin() { return tMin; }
    public String gettMax() { return tMax; }
    public String getPredWindDir() { return predWindDir; }
    public int getIdWeatherType() { return idWeatherType; }
    public int getClassWindSpeed() { return classWindSpeed; }
    public String getLongitude() { return longitude; }
    public String getForecastDate() { return forecastDate; }
    public String getLatitude() { return latitude; }
    public int getGlobalIdLocal() { return globalIdLocal; }
    public String getDataUpdate() { return dataUpdate; }
    public Date getLastRefresh() { return lastRefresh; }


    // SETTERS:
    public void setId(@NonNull String id) { this.id = id; }
    public void setOwner(String owner) { this.owner = owner; }
    public void setCountry(String country) { this.country = country; }
    public void setRegNumber(int regNumber) { this.regNumber = regNumber; }
    public void setPrecipitaProb(String precipitaProb) { this.precipitaProb = precipitaProb; }
    public void settMin(String tMin) { this.tMin = tMin; }
    public void settMax(String tMax) { this.tMax = tMax; }
    public void setPredWindDir(String predWindDir) { this.predWindDir = predWindDir; }
    public void setIdWeatherType(int idWeatherType) { this.idWeatherType = idWeatherType; }
    public void setClassWindSpeed(int classWindSpeed) { this.classWindSpeed = classWindSpeed; }
    public void setLongitude(String longitude) { this.longitude = longitude; }
    public void setForecastDate(String forecastDate) { this.forecastDate = forecastDate; }
    public void setLatitude(String latitude) { this.latitude = latitude; }
    public void setGlobalIdLocal(int globalIdLocal) { this.globalIdLocal = globalIdLocal; }
    public void setDataUpdate(String dataUpdate) { this.dataUpdate = dataUpdate; }
    public void setLastRefresh(Date lastRefresh) { this.lastRefresh = lastRefresh; }
}
