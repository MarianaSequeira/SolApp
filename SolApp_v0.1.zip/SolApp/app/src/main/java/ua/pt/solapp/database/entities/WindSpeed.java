package ua.pt.solapp.database.entities;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Mariana on 22/12/2018.
 */

@Entity
public class WindSpeed {

    @PrimaryKey
    @NonNull
    @SerializedName("id")
    @Expose
    private String id;

    @SerializedName("owner")
    @Expose
    private String owner;

    @SerializedName("country")
    @Expose
    private String country;

    @SerializedName("descClassWindSpeedDailyEN")
    @Expose
    private String descClassWindSpeedDailyEN;

    @SerializedName("descClassWindSpeedDailyPT")
    @Expose
    private String descClassWindSpeedDailyPT;

    @SerializedName("classWindSpeed")
    @Expose
    private String classWindSpeed;


    // CONSTRUCTOR:
    public WindSpeed(@NonNull String id, String owner, String country, String descClassWindSpeedDailyEN, String descClassWindSpeedDailyPT, String classWindSpeed) {
        this.id = id;
        this.owner = owner;
        this.country = country;
        this.descClassWindSpeedDailyEN = descClassWindSpeedDailyEN;
        this.descClassWindSpeedDailyPT = descClassWindSpeedDailyPT;
        this.classWindSpeed = classWindSpeed;
    }


    // GETTERS:
    @NonNull
    public String getId() { return id; }
    public String getOwner() { return owner; }
    public String getCountry() { return country; }
    public String getDescClassWindSpeedDailyEN() { return descClassWindSpeedDailyEN; }
    public String getDescClassWindSpeedDailyPT() { return descClassWindSpeedDailyPT; }
    public String getClassWindSpeed() { return classWindSpeed; }


    // SETTERS:
    public void setId(@NonNull String id) { this.id = id; }
    public void setOwner(String owner) { this.owner = owner; }
    public void setCountry(String country) { this.country = country; }
    public void setDescClassWindSpeedDailyEN(String descClassWindSpeedDailyEN) { this.descClassWindSpeedDailyEN = descClassWindSpeedDailyEN; }
    public void setDescClassWindSpeedDailyPT(String descClassWindSpeedDailyPT) { this.descClassWindSpeedDailyPT = descClassWindSpeedDailyPT; }
    public void setClassWindSpeed(String classWindSpeed) { this.classWindSpeed = classWindSpeed; }
}
