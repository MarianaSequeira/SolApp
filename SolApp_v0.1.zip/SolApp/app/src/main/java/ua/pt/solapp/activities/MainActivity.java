package ua.pt.solapp.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ua.pt.solapp.R;

/**
 * Created by Mariana on 22/12/2018.
 */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
