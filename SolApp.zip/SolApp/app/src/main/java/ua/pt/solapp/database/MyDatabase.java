package ua.pt.solapp.database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;


import ua.pt.solapp.database.converter.DateConverter;
import ua.pt.solapp.database.dao.WeatherForecastDao;
import ua.pt.solapp.database.entities.DistrictID;
import ua.pt.solapp.database.entities.DistrictIDData;
import ua.pt.solapp.database.entities.WeatherForecast;
import ua.pt.solapp.database.entities.WeatherForecastData;
import ua.pt.solapp.database.entities.WeatherID;
import ua.pt.solapp.database.entities.WeatherIDData;
import ua.pt.solapp.database.entities.WindSpeed;
import ua.pt.solapp.database.entities.WindSpeedData;

/**
 * Created by Philippe on 02/03/2018.
 */

@Database(entities = {WeatherForecast.class, DistrictID.class, WeatherID.class, WindSpeed.class, WeatherForecastData.class, DistrictIDData.class, WeatherIDData.class, WindSpeedData.class}, version = 1, exportSchema = false)
@TypeConverters(DateConverter.class)
public abstract class MyDatabase extends RoomDatabase {

    // --- SINGLETON ---
    private static volatile MyDatabase INSTANCE;

    // --- DAO ---
    public abstract WeatherForecastDao weatherForecastDao();
}
