package ua.pt.solapp.database.converter;

import android.arch.persistence.room.TypeConverter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;

import ua.pt.solapp.database.entities.DistrictIDData;
import ua.pt.solapp.database.entities.WeatherForecastData;
import ua.pt.solapp.database.entities.WeatherID;
import ua.pt.solapp.database.entities.WeatherIDData;
import ua.pt.solapp.database.entities.WindSpeed;
import ua.pt.solapp.database.entities.WindSpeedData;

/**
 * Created by Mariana on 22/12/2018.
 */

public class DateConverter {
    @TypeConverter
    public static Date toDate(Long timestamp) {
        return timestamp == null ? null : new Date(timestamp);
    }

    @TypeConverter
    public static Long toTimestamp(Date date) {
        return date == null ? null : date.getTime();
    }


    @TypeConverter
    public static String fromWeatherForecastData (List<WeatherForecastData> weatherForecastDataList) {

        if (weatherForecastDataList == null) {
            return (null);
        }

        Gson gson = new Gson();
        Type type = new TypeToken<List<WeatherForecastData>>(){}.getType();

        String json = gson.toJson(weatherForecastDataList, type);
        return json;
    }

    @TypeConverter
    public static List<WeatherForecastData> toWeatherForecastData (String weatherForecastData) {

        if (weatherForecastData == null) {
            return (null);
        }

        Gson gson = new Gson();
        Type type = new TypeToken<List<WeatherForecastData>>(){}.getType();

        List<WeatherForecastData> weatherForecastDataList = gson.fromJson(weatherForecastData, type);
        return weatherForecastDataList;
    }

    @TypeConverter
    public static String fromDistrictIDData (List<DistrictIDData> districtIDDataList) {

        if (districtIDDataList == null) {
            return (null);
        }

        Gson gson = new Gson();
        Type type = new TypeToken<List<DistrictIDData>>(){}.getType();

        String json = gson.toJson(districtIDDataList, type);
        return json;
    }

    @TypeConverter
    public static List<DistrictIDData> toDistrictIDData (String districtIDData) {

        if (districtIDData == null) {
            return (null);
        }

        Gson gson = new Gson();
        Type type = new TypeToken<List<DistrictIDData>>(){}.getType();

        List<DistrictIDData> districtIDDataList = gson.fromJson(districtIDData, type);
        return districtIDDataList;
    }

    @TypeConverter
    public static String fromWeatherIDData (List<WeatherIDData> weatherIDDataList) {

        if (weatherIDDataList == null) {
            return (null);
        }

        Gson gson = new Gson();
        Type type = new TypeToken<List<WeatherIDData>>(){}.getType();

        String json = gson.toJson(weatherIDDataList, type);
        return json;
    }

    @TypeConverter
    public static List<WeatherIDData> toWeatherIDData (String weatherIDData) {

        if (weatherIDData == null) {
            return (null);
        }

        Gson gson = new Gson();
        Type type = new TypeToken<List<WeatherIDData>>(){}.getType();

        List<WeatherIDData> weatherIDDataList = gson.fromJson(weatherIDData, type);
        return weatherIDDataList;
    }

    @TypeConverter
    public static String fromWindSpeedData (List<WindSpeedData> windSpeedDataList) {

        if (windSpeedDataList == null) {
            return (null);
        }

        Gson gson = new Gson();
        Type type = new TypeToken<List<WindSpeedData>>(){}.getType();

        String json = gson.toJson(windSpeedDataList, type);
        return json;
    }

    @TypeConverter
    public static List<WindSpeedData> toWindSpeedData (String windSpeedData) {

        if (windSpeedData == null) {
            return (null);
        }

        Gson gson = new Gson();
        Type type = new TypeToken<List<WindSpeedData>>(){}.getType();

        List<WindSpeedData> windSpeedDataList = gson.fromJson(windSpeedData, type);
        return windSpeedDataList;
    }
}
