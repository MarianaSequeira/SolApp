package ua.pt.solapp.view_models;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.ViewModel;

import javax.inject.Inject;

import ua.pt.solapp.database.entities.WeatherID;
import ua.pt.solapp.repositories.WeatherIDRepository;

public class WeatherIDViewModel extends ViewModel {

    private LiveData<WeatherID> weatherID;
    private WeatherIDRepository weatherIDRepository;

    @Inject
    public WeatherIDViewModel(WeatherIDRepository weatherIDRepository) {
        this.weatherIDRepository = weatherIDRepository;
    }

    // ----

    public void init() {
        if (this.weatherID != null) {
            return;
        }
        weatherID = weatherIDRepository.getWeatherID();
    }

    public LiveData<WeatherID> getWeatherID() {
        return this.weatherID;
    }
}
