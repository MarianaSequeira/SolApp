package ua.pt.solapp.fragments;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.lang.reflect.Field;

import javax.inject.Inject;

import butterknife.ButterKnife;
import dagger.android.support.AndroidSupportInjection;
import ua.pt.solapp.R;
import ua.pt.solapp.database.entities.WeatherForecast;
import ua.pt.solapp.database.entities.WeatherID;
import ua.pt.solapp.database.entities.WeatherIDData;
import ua.pt.solapp.view_models.WeatherForecastViewModel;
import ua.pt.solapp.view_models.WeatherIDViewModel;

public class MapFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnInfoWindowClickListener {

    private final String TAG = "MapFragment";

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    private WeatherForecastViewModel WFviewModel;
    private WeatherIDViewModel WDviewModel;
    private SupportMapFragment fragment;

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    private GoogleMap mMap;

    private String latitude;
    private String longitude;
    private String districtName;
    private int globalIdLocal;
    private String weathertype;

    private TextView districtID;

    private ViewPager mPager;

    private SupportMapFragment map;
    private GoogleMap mGoogleMap;
    private MapView mMapView;
    private View mView;


    public MapFragment () {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_maps, container, false);
        ButterKnife.bind(this, mView);
        districtID = mView.findViewById(R.id.districtID);
        pref = getActivity().getSharedPreferences("Settings", Context.MODE_PRIVATE); // 0 - for private mode
        editor = pref.edit();

        return mView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.configureDagger();
    }

    private void configureDagger(){
        AndroidSupportInjection.inject(this);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mMapView = (MapView) mView.findViewById(R.id.map);

        if (mMapView != null) {
            mMapView.onCreate(null);
            mMapView.onResume();
            mMapView.getMapAsync(this);
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

        try {
            Field childFragmentManager = Fragment.class
                    .getDeclaredField("mChildFragmentManager");
            childFragmentManager.setAccessible(true);
            childFragmentManager.set(this, null);

        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public void set(String latitude, String longitude, String districtName, String globalIdLocal){
        this.latitude = latitude;
        this.longitude = longitude;
        this.districtName = districtName;

        try {
            this.globalIdLocal = Integer.parseInt(globalIdLocal);
        } catch (Exception e ) {
            this.globalIdLocal = 1110600;
        }


        WFviewModel = ViewModelProviders.of(this, viewModelFactory).get(WeatherForecastViewModel.class);
        WFviewModel.init(this.globalIdLocal);
        WFviewModel.getWeatherForecast().observe(this, weatherForecast -> updateUI(weatherForecast));
    }

    private void updateUI(@Nullable WeatherForecast weatherForecast){
        if (weatherForecast != null){

            int id  = weatherForecast.getData().get(0).getIdWeatherType();
            WDviewModel = ViewModelProviders.of(this, viewModelFactory).get(WeatherIDViewModel.class);
            WDviewModel.init();
            WDviewModel.getWeatherID().observe(this, weatherID -> getWeatherID(weatherID, id));

        }
    }

    private void getWeatherID(@Nullable WeatherID weatherID, int id){
        if (weatherID != null){

            for (WeatherIDData w : weatherID.getData()) {
                if (id == w.getIdWeatherType()) {
                    this.weathertype = w.getDescIdWeatherTypeEN();
                    onMapReady(mMap);
                }
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        MapsInitializer.initialize(getContext());

        mMap = googleMap;

        mMap.clear();

        if (latitude != null) {
            LatLng coord = new LatLng(Double.parseDouble(this.latitude), Double.parseDouble(this.longitude));

            Log.d(TAG, "WeatherType: " +weathertype + " Lat: "+this.latitude+ " Log: " + this.longitude);

            Marker melbourne = mMap.addMarker(new MarkerOptions()
                    .position(coord)
                    .title(weathertype)
                    .snippet("See More Info")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));

            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(coord, 7f));
            melbourne.showInfoWindow();
            mMap.setOnInfoWindowClickListener(this);
            districtID.setText(districtName);
        }





    }

    public void set(ViewPager v) {
        mPager = v;
    }

    @Override
    public void onInfoWindowClick(Marker marker) {
        editor.putString("globalID", globalIdLocal+""); // Storing float
        editor.putString("districtName", districtName);
        editor.apply();
        mPager.setCurrentItem(0);
    }
}
