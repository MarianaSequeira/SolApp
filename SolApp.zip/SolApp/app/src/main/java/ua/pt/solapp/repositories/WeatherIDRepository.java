package ua.pt.solapp.repositories;

import android.arch.lifecycle.LiveData;
import android.util.Log;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Executor;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import ua.pt.solapp.App;
import ua.pt.solapp.api.WeatherWebService;
import ua.pt.solapp.database.dao.WeatherForecastDao;
import ua.pt.solapp.database.entities.DistrictID;
import ua.pt.solapp.database.entities.WeatherID;
import ua.pt.solapp.database.entities.WindSpeed;

public class WeatherIDRepository {
    private static int FRESH_TIMEOUT_IN_MINUTES = 1;

    private final WeatherWebService webservice;
    private final WeatherForecastDao weatherForecastDao;
    private final Executor executor;

    public WeatherIDRepository(WeatherWebService webservice, WeatherForecastDao weatherForecastDao, Executor executor) {
        this.webservice = webservice;
        this.weatherForecastDao = weatherForecastDao;
        this.executor = executor;
    }

    // ---

    public LiveData<WeatherID> getWeatherID() {
        getWeatherIDs(); // try to refresh data if possible from Github Api
        return weatherForecastDao.getWeatherType(); // return a LiveData directly from the database.
    }

    // ---

    private void getWeatherIDs() {
        executor.execute(() -> {
            // Check if user was fetched recently
            {
                webservice.getWeatherId().enqueue(new Callback<WeatherID>() {
                    @Override
                    public void onResponse(Call<WeatherID> call, Response<WeatherID> response) {
                        Log.e("TAG", "DATA REFRESHED FROM NETWORK");
                        Toast.makeText(App.context, "Data refreshed from network !", Toast.LENGTH_LONG).show();
                        executor.execute(() -> {
                            WeatherID weatherID = response.body();
                            weatherForecastDao.saveWeatherID(weatherID);
                        });
                    }

                    @Override
                    public void onFailure(Call<WeatherID> call, Throwable t) { }
                });
            }
        });
    }


}
