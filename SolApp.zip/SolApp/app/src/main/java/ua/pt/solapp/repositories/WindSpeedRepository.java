package ua.pt.solapp.repositories;

import android.arch.lifecycle.LiveData;
import android.util.Log;
import android.widget.Toast;

import java.util.concurrent.Executor;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import ua.pt.solapp.App;
import ua.pt.solapp.api.WeatherWebService;
import ua.pt.solapp.database.dao.WeatherForecastDao;
import ua.pt.solapp.database.entities.WeatherID;
import ua.pt.solapp.database.entities.WindSpeed;

public class WindSpeedRepository {
    private static int FRESH_TIMEOUT_IN_MINUTES = 1;

    private final WeatherWebService webservice;
    private final WeatherForecastDao weatherForecastDao;
    private final Executor executor;

    public WindSpeedRepository(WeatherWebService webservice, WeatherForecastDao weatherForecastDao, Executor executor) {
        this.webservice = webservice;
        this.weatherForecastDao = weatherForecastDao;
        this.executor = executor;
    }

    // ---

    public LiveData<WindSpeed> getWindSpeed() {
        getWindSpeedValues(); // try to refresh data if possible from Github Api
        return weatherForecastDao.getWindSpeed(); // return a LiveData directly from the database.
    }

    // ---

    private void getWindSpeedValues() {
        executor.execute(() -> {
            // Check if user was fetched recently
            {
                webservice.getWindSpeed().enqueue(new Callback<WindSpeed>() {
                    @Override
                    public void onResponse(Call<WindSpeed> call, Response<WindSpeed> response) {
                        Log.e("TAG", "DATA REFRESHED FROM NETWORK");
                        Toast.makeText(App.context, "Data refreshed from network !", Toast.LENGTH_LONG).show();
                        executor.execute(() -> {
                            WindSpeed windSpeed = response.body();
                            weatherForecastDao.saveWindSpeed(windSpeed);
                        });
                    }

                    @Override
                    public void onFailure(Call<WindSpeed> call, Throwable t) { }
                });
            }
        });
    }
}
