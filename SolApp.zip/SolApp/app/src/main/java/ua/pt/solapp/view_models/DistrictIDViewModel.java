package ua.pt.solapp.view_models;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.ViewModel;

import javax.inject.Inject;

import ua.pt.solapp.database.entities.DistrictID;
import ua.pt.solapp.repositories.DistrictIDRepository;

public class DistrictIDViewModel extends ViewModel {

    private LiveData<DistrictID> districtID;
    private DistrictIDRepository districtIDRepository;

    @Inject
    public DistrictIDViewModel(DistrictIDRepository districtIDRepository) {
        this.districtIDRepository = districtIDRepository;
    }

    // ----

    public void init() {
        if (this.districtID != null) {
            return;
        }
        districtID = districtIDRepository.getDistrict();
    }

    public LiveData<DistrictID> getDistrictID() {
        return this.districtID;
    }

}
