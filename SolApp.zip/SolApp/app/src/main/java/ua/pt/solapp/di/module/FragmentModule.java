package ua.pt.solapp.di.module;


import dagger.Module;
import dagger.android.ContributesAndroidInjector;
import ua.pt.solapp.database.entities.DistrictID;
import ua.pt.solapp.fragments.DistrictFragment;
import ua.pt.solapp.fragments.ForecastFragment;
import ua.pt.solapp.fragments.MapFragment;

/**
 * Created by Philippe on 02/03/2018.
 */

@Module
public abstract class FragmentModule {


    @ContributesAndroidInjector
    abstract ForecastFragment contributeUserProfileFragment();

    @ContributesAndroidInjector
    abstract DistrictFragment contributeDistrictID();

    @ContributesAndroidInjector
    abstract MapFragment contributeMapFragment();


}
