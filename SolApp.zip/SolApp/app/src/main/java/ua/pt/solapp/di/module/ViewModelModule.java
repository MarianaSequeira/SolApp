package ua.pt.solapp.di.module;


import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;

import dagger.Binds;
import dagger.Module;
import dagger.multibindings.IntoMap;
import ua.pt.solapp.di.key.ViewModelKey;
import ua.pt.solapp.view_models.DistrictIDViewModel;
import ua.pt.solapp.view_models.FactoryViewModel;
import ua.pt.solapp.view_models.WeatherForecastViewModel;
import ua.pt.solapp.view_models.WeatherIDViewModel;
import ua.pt.solapp.view_models.WindSpeedViewModel;

@Module
public abstract class ViewModelModule {

    @Binds
    @IntoMap
    @ViewModelKey(WeatherForecastViewModel.class)
    abstract ViewModel bindWeatherForecastViewModel(WeatherForecastViewModel repoViewModel);

    @Binds
    @IntoMap
    @ViewModelKey(DistrictIDViewModel.class)
    abstract ViewModel bindDistrictIDViewModel(DistrictIDViewModel repoViewModel);

    @Binds
    @IntoMap
    @ViewModelKey(WeatherIDViewModel.class)
    abstract ViewModel bindWeatherIDViewModel(WeatherIDViewModel repoViewModel);

    @Binds
    @IntoMap
    @ViewModelKey(WindSpeedViewModel.class)
    abstract ViewModel bindWindSpeedViewModel(WindSpeedViewModel repoViewModel);

    @Binds
    abstract ViewModelProvider.Factory bindViewModelFactory(FactoryViewModel factory);
}