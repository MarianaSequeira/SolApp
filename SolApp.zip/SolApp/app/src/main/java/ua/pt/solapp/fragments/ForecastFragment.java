package ua.pt.solapp.fragments;


import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.support.AndroidSupportInjection;
import ua.pt.solapp.R;
import ua.pt.solapp.database.entities.DistrictID;
import ua.pt.solapp.database.entities.WeatherForecast;
import ua.pt.solapp.database.entities.WeatherID;
import ua.pt.solapp.database.entities.WeatherIDData;
import ua.pt.solapp.database.entities.WindSpeed;
import ua.pt.solapp.view_models.DistrictIDViewModel;
import ua.pt.solapp.view_models.WeatherForecastViewModel;
import ua.pt.solapp.view_models.WeatherIDViewModel;
import ua.pt.solapp.view_models.WindSpeedViewModel;

/**
 * A simple {@link Fragment} subclass.
 */
public class ForecastFragment extends Fragment {

    private final String TAG = "ForecastFragment";

    // FOR DATA
    public static final String UID_KEY = "1110600";

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    private WeatherForecastViewModel WFviewModel;
    private WeatherIDViewModel WDviewModel;
    private WindSpeedViewModel WSviewModel;

    private int globalIdLocal;
    private int id = -1;
    private int id1, id2, id3, id4;
    private String districtName = "Aveiro";
    private SharedPreferences pref;
    private String globalID;

    @BindView(R.id.tempMax)
    TextView tempMax;
    @BindView(R.id.tempMin)
    TextView tempMin;
    @BindView(R.id.windDirection)
    TextView windDirection;
    @BindView(R.id.precipitation)
    TextView precipitation;
    @BindView(R.id.districtID)
    TextView districtID;
    @BindView(R.id.windSpeed)
    TextView windSpeed;
    @BindView(R.id.weatherType)
    TextView weatherType;

    @BindView(R.id.img)
    ImageView img;

    @BindView(R.id.imgDay1)
    ImageView imgDay1;
    @BindView(R.id.imgDay2)
    ImageView imgDay2;
    @BindView(R.id.imgDay3)
    ImageView imgDay3;
    @BindView(R.id.imgDay4)
    ImageView imgDay4;

    @BindView(R.id.day1)
    TextView day1;
    @BindView(R.id.day2)
    TextView day2;
    @BindView(R.id.day3)
    TextView day3;
    @BindView(R.id.day4)
    TextView day4;

    @BindView(R.id.descDay1)
    TextView descDay1;
    @BindView(R.id.descDay2)
    TextView descDay2;
    @BindView(R.id.descDay3)
    TextView descDay3;
    @BindView(R.id.descDay4)
    TextView descDay4;

    @BindView(R.id.temperatureGraph)
    LineChart mChar;


    public ForecastFragment() { }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_forecast, container, false);
        ButterKnife.bind(this, view);

        pref = getActivity().getSharedPreferences("Settings", Context.MODE_PRIVATE); // 0 - for private mode

        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.configureDagger();
        this.configureViewModel(globalID);
    }

    // -----------------
    // CONFIGURATION
    // -----------------

    public void set(String globalID, String districtName){
        this.globalID = globalID;
        this.districtName = districtName;
        configureViewModel(globalID);
    }

    private void configureDagger(){
        AndroidSupportInjection.inject(this);
    }

    private void configureViewModel(String globalID){

        if (globalID != null) {
            globalIdLocal = Integer.parseInt(globalID);

        } else {
            globalIdLocal = Integer.parseInt(UID_KEY);
        }

        Log.d(TAG, globalIdLocal+"   -- ");

        WFviewModel = ViewModelProviders.of(this, viewModelFactory).get(WeatherForecastViewModel.class);
        WFviewModel.init(globalIdLocal);
        WFviewModel.getWeatherForecast().observe(this, weatherForecast -> updateUI(weatherForecast));

        WSviewModel = ViewModelProviders.of(this, viewModelFactory).get(WindSpeedViewModel.class);
        WSviewModel.init();
        WSviewModel.getWindSpeed().observe(this, windSpeed -> getWindSpeed(windSpeed));

    }

    // -----------------
    // UPDATE UI
    // -----------------


    private void updateUI(@Nullable WeatherForecast weatherForecast){
        if (weatherForecast != null){
            this.tempMax.setText(weatherForecast.getData().get(0).getTempMax()+"");
            this.tempMin.setText(weatherForecast.getData().get(0).getTempMin()+"");
            this.windDirection.setText("  "+weatherForecast.getData().get(0).getPredWindDir());
            this.precipitation.setText("  "+weatherForecast.getData().get(0).getPrecipitaProb() + "%");
            this.districtID.setText(districtName);

            id  = weatherForecast.getData().get(0).getIdWeatherType();
            id1 = weatherForecast.getData().get(1).getIdWeatherType();
            id2 = weatherForecast.getData().get(2).getIdWeatherType();
            id3 = weatherForecast.getData().get(3).getIdWeatherType();
            id4 = weatherForecast.getData().get(4).getIdWeatherType();

            String[] data = weatherForecast.getData().get(1).getForecastDate().split("-");
            this.day1.setText(data[2]+"/"+data[1]);
            data = weatherForecast.getData().get(2).getForecastDate().split("-");
            this.day2.setText(data[2]+"/"+data[1]);
            data = weatherForecast.getData().get(3).getForecastDate().split("-");
            this.day3.setText(data[2]+"/"+data[1]);
            data = weatherForecast.getData().get(4).getForecastDate().split("-");
            this.day4.setText(data[2]+"/"+data[1]);

            this.img.setImageResource(discoveryImg(id));
            this.imgDay1.setImageResource(discoveryImg(id1));
            this.imgDay2.setImageResource(discoveryImg(id2));
            this.imgDay3.setImageResource(discoveryImg(id3));
            this.imgDay4.setImageResource(discoveryImg(id4));

            WDviewModel = ViewModelProviders.of(this, viewModelFactory).get(WeatherIDViewModel.class);
            WDviewModel.init();
            WDviewModel.getWeatherID().observe(this, weatherID -> getWeatherID(weatherID, id, id1,id2, id3, id4));


            mChar.setDragEnabled(false);
            mChar.setScaleEnabled(true);

            ArrayList<Entry> tempMax = new ArrayList<>();
            ArrayList<Entry> tempMin = new ArrayList<>();

            tempMax.add(new Entry(0, Float.parseFloat(weatherForecast.getData().get(0).getTempMax())));
            tempMax.add(new Entry(1, Float.parseFloat(weatherForecast.getData().get(1).getTempMax())));
            tempMax.add(new Entry(2, Float.parseFloat(weatherForecast.getData().get(2).getTempMax())));
            tempMax.add(new Entry(3, Float.parseFloat(weatherForecast.getData().get(3).getTempMax())));
            tempMax.add(new Entry(4, Float.parseFloat(weatherForecast.getData().get(4).getTempMax())));

            tempMin.add(new Entry(0, Float.parseFloat(weatherForecast.getData().get(0).getTempMin())));
            tempMin.add(new Entry(1, Float.parseFloat(weatherForecast.getData().get(1).getTempMin())));
            tempMin.add(new Entry(2, Float.parseFloat(weatherForecast.getData().get(2).getTempMin())));
            tempMin.add(new Entry(3, Float.parseFloat(weatherForecast.getData().get(3).getTempMin())));
            tempMin.add(new Entry(4, Float.parseFloat(weatherForecast.getData().get(4).getTempMin())));

            LineDataSet set1 = new LineDataSet(tempMin, "Variação da Temperatura Máxima");
            LineDataSet set2 = new LineDataSet(tempMax, "Variação da Temperatura Mínima");

            set1.setFillAlpha(110);
            set1.setCircleColor(Color.rgb(65, 160, 216));
            set1.setLineWidth(4f);
            set1.setColor(Color.rgb(65, 160, 216));
            set1.setValueTextColor(Color.rgb(65, 160, 216));
            set1.setValueTextSize(14f);


            set2.setFillAlpha(110);
            set2.setCircleColor(Color.rgb(252, 182, 66));
            set2.setLineWidth(4f);
            set2.setColor(Color.rgb(252, 188, 66));
            set2.setCircleRadius(4f);
            set2.setValueTextColor(Color.rgb(252, 188, 66));
            set2.setValueTextSize(14f);

            LineData data2 = new LineData(set1, set2);
            mChar.setData(data2);

            // remove axis
            YAxis leftAxis = mChar.getAxisLeft();
            leftAxis.setEnabled(false);
            YAxis rightAxis = mChar.getAxisRight();
            rightAxis.setEnabled(false);
            XAxis xAxis = mChar.getXAxis();
            xAxis.setEnabled(false);
            Legend legend = mChar.getLegend();
            legend.setEnabled(false);
            mChar.setDrawGridBackground(false);
            mChar.setDrawBorders(false);
            mChar.invalidate();
            mChar.getDescription().setEnabled(false);

        }
    }

    private int discoveryImg(int id) {
        if (id == 1) {
            return R.drawable.img1;
        } else if (id == 2 || id == 3 ) {
            return R.drawable.img2;
        } else if (id == 4 || id == 5 || id == 16 || id == 17 || id == 27 || id == 26 || id == 25) {
            return R.drawable.cloudyy;
        } else if (id == 6 || id == 9 || id == 12 || id == 15) {
            return R.drawable.rain1;
        } else if (id == 7 || id == 10 || id == 13) {
            return R.drawable.rain2;
        } else if (id == 8 || id == 11 || id == 14) {
            return R.drawable.rain;
        } else if (id == 18 || id == 21 ) {
            return R.drawable.snowing;
        } else if (id == 22 || id == 24 ) {
            return R.drawable.snowing2;
        } else if (id == 19) {
            return R.drawable.storm1;
        } else if (id == 20 || id == 23) {
            return R.drawable.storm;
        } else {
            return R.drawable.nothingtoshow;
        }
    }

    private void getWeatherID(@Nullable WeatherID weatherID, int id, int id1, int id2, int id3, int id4){
        if (weatherID != null){
            if (id != -1){
                for (WeatherIDData w : weatherID.getData()) {
                    if (id == w.getIdWeatherType()) {
                        this.weatherType.setText(w.getDescIdWeatherTypeEN()+"");
                    }
                    if (id1 == w.getIdWeatherType()) {
                        this.descDay1.setText(w.getDescIdWeatherTypeEN()+"");
                    }
                    if (id2 == w.getIdWeatherType()) {
                        this.descDay2.setText(w.getDescIdWeatherTypeEN()+"");
                    }
                    if (id3 == w.getIdWeatherType()) {
                        this.descDay3.setText(w.getDescIdWeatherTypeEN()+"");
                    }
                    if (id4 == w.getIdWeatherType()) {
                        Log.d(TAG, "ID4: " + id4);
                        this.descDay4.setText(w.getDescIdWeatherTypeEN()+"");
                    }
                }
            }
        }
    }

    private void getWindSpeed(@Nullable WindSpeed windSpeed){
        if (windSpeed != null){
            this.windSpeed.setText("  "+windSpeed.getData().get(2).getDescClassWindSpeedDailyEN()+"");
        }
    }

}
