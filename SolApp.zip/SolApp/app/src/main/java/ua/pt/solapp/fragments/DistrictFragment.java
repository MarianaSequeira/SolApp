package ua.pt.solapp.fragments;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.LongDef;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import javax.inject.Inject;

import butterknife.ButterKnife;
import dagger.android.support.AndroidSupportInjection;
import ua.pt.solapp.R;
import ua.pt.solapp.activities.MainActivity;
import ua.pt.solapp.database.entities.DistrictID;
import ua.pt.solapp.database.entities.DistrictIDData;
import ua.pt.solapp.view_models.DistrictIDViewModel;

public class DistrictFragment extends Fragment {

    private final String TAG = "DistrictFragment";

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    private DistrictIDViewModel DDviewModel;

    private ArrayList<String[]> mDistrict = new ArrayList<>();
    private ListView listView;

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private ViewPager mPager;

    public DistrictFragment() { }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_district, container, false);
        ButterKnife.bind(this, view);
        listView = view.findViewById(R.id.listView1);

        pref = getActivity().getSharedPreferences("Settings", Context.MODE_PRIVATE); // 0 - for private mode
        editor = pref.edit();

        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.configureDagger();
        this.configureViewModel();
    }

    // -----------------
    // CONFIGURATION
    // -----------------

    private void configureDagger(){
        AndroidSupportInjection.inject(this);
    }

    private void configureViewModel(){

        DDviewModel = ViewModelProviders.of(this, viewModelFactory).get(DistrictIDViewModel.class);
        DDviewModel.init();
        DDviewModel.getDistrictID().observe(this, districtID -> getDistrictID(districtID));

    }

    public void set(ViewPager v) {
        mPager = v;
    }

    // -----------------
    // UPDATE UI
    // -----------------

    private void getDistrictID(@Nullable DistrictID districtID){

        UsersAdapter adapter = new UsersAdapter(getContext(), new ArrayList<String[]>());

        if (districtID != null){
            //this.districtID.setText(districtID.getData().get(0).getGlobalIdLocal()+"");

            for (DistrictIDData data : districtID.getData()) {
                String[] d = {data.getGlobalIdLocal()+"", data.getLocal(), data.getLatitude(), data.getLongitude()};
                mDistrict.add(d);
                adapter.add(d);
            }

            listView.setAdapter(adapter);
        }
    }

    public class UsersAdapter extends ArrayAdapter<String[]> {
        public UsersAdapter(Context context, ArrayList<String[]> users) {
            super(context, 0, users);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_district, parent, false);
            }

            final CardView card_view = convertView.findViewById(R.id.cardView2);
            final ImageButton map = convertView.findViewById(R.id.map);
            TextView districtName = convertView.findViewById(R.id.districtName);
            TextView globalIDDistrict = convertView.findViewById(R.id.globalIDDistrict);

            final String[] data = getItem(position);

            card_view.setTag(position);
            card_view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    editor.putString("globalID", data[0]); // Storing float
                    editor.putString("districtName", data[1]);
                    editor.apply();
                    mPager.setCurrentItem(0);


                }
            });

            card_view.setTag(position);

            map.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editor.putString("latitude", data[2]); // Storing float
                    editor.putString("longitude", data[3]);
                    editor.putString("districtName", data[1]);
                    editor.putString("globalIdLocal", data[0]);
                    editor.apply();
                    Log.d(TAG, "Latitude: " + data[2] + " Longitude: " + data[3]);
                    mPager.setCurrentItem(2);
                }
            });
            districtName.setText(data[1]);
            globalIDDistrict.setText("[ Global ID: " + data[0] + "]");

            return convertView;
        }
    }
}
