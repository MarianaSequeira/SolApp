package ua.pt.solapp.api;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import ua.pt.solapp.database.entities.DistrictID;
import ua.pt.solapp.database.entities.WeatherForecast;
import ua.pt.solapp.database.entities.WeatherID;
import ua.pt.solapp.database.entities.WindSpeed;

public interface WeatherWebService {

    @GET("/open-data/forecast/meteorology/cities/daily/{globalIdLocal}.json")
    Call<WeatherForecast> getWeatherForecast(@Path("globalIdLocal") int weatherForecast);

    @GET("/open-data/distrits-islands.json")
    Call<DistrictID> getDistrictId();

    @GET("/open-data/weather-type-classe.json")
    Call<WeatherID> getWeatherId();

    @GET("/open-data/wind-speed-daily-classe.json")
    Call<WindSpeed> getWindSpeed();
}
