package ua.pt.solapp.activities;

import android.arch.lifecycle.ViewModelProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import javax.inject.Inject;

import dagger.android.AndroidInjection;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.support.HasSupportFragmentInjector;
import ua.pt.solapp.R;
import ua.pt.solapp.fragments.DistrictFragment;
import ua.pt.solapp.fragments.ForecastFragment;
import ua.pt.solapp.fragments.MapFragment;

/**
 * Created by Mariana on 22/12/2018.
 */

public class MainActivity extends AppCompatActivity implements HasSupportFragmentInjector, View.OnClickListener {

    public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";

    private final String TAG = "MainActivity";
    private static final int NUM_PAGES = 3;

    @Inject
    DispatchingAndroidInjector<Fragment> dispatchingAndroidInjector;


    private int[] layouts = {R.layout.fragment_forecast, R.layout.fragment_district, R.layout.fragment_maps};
    private ScreenSlidePagerAdapter myPagerAdapter;
    private ViewPager mPager;

    private static String USER_LOGIN = "1110600";

    private ImageButton btnLocation, btnBack;
    private SharedPreferences pref;

    ForecastFragment forecastFragment = new ForecastFragment();
    DistrictFragment districtFragment = new DistrictFragment();
    MapFragment mapFragment = new MapFragment();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLocation = findViewById(R.id.btnLocation);
        btnLocation.setOnClickListener(this);
        btnBack = findViewById(R.id.btnBack);
        btnBack.setVisibility(View.INVISIBLE);
        btnBack.setOnClickListener(this);

        pref = this.getSharedPreferences("Settings", Context.MODE_PRIVATE); // 0 - for private mode


        this.configureDagger();
        this.showFragment(savedInstanceState);
    }

    @Override
    public DispatchingAndroidInjector<Fragment> supportFragmentInjector() {
        return dispatchingAndroidInjector;
    }

    // ---

    private void showFragment(Bundle savedInstanceState){
        if (savedInstanceState == null) {

            mPager = (ViewPager) findViewById(R.id.viewPager);
            myPagerAdapter = new ScreenSlidePagerAdapter(getSupportFragmentManager());
            mPager.setAdapter(myPagerAdapter);

            mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int i, float v, int i1) { }

                @Override
                public void onPageSelected(int i) {

                    if (i == 0) {
                        btnLocation.setVisibility(View.VISIBLE);
                        btnBack.setVisibility(View.INVISIBLE);
                        forecastFragment.set(pref.getString("globalID", null), pref.getString("districtName", null));
                    } else if (i == 1) {
                        btnBack.setVisibility(View.VISIBLE);
                        btnLocation.setVisibility(View.INVISIBLE);
                    } else if (i == 2) {
                        btnBack.setVisibility(View.VISIBLE);
                        btnLocation.setVisibility(View.INVISIBLE);
                        mapFragment.set(pref.getString("latitude", null), pref.getString("longitude", null), pref.getString("districtName", null), pref.getString("globalIdLocal", null));

                    }
                }

                @Override
                public void onPageScrollStateChanged(int i) { }
            });
        }
    }

    private void configureDagger(){
        AndroidInjection.inject(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnBack:
                if (mPager.getCurrentItem() == 1) {
                    mPager.setCurrentItem(0);
                    btnBack.setVisibility(View.INVISIBLE);
                    btnLocation.setVisibility(View.VISIBLE);
                } else {
                    mPager.setCurrentItem(1);
                    btnBack.setVisibility(View.VISIBLE);
                    btnLocation.setVisibility(View.INVISIBLE);
                }

                break;
            case R.id.btnLocation:
                mPager.setCurrentItem(1);
                btnBack.setVisibility(View.VISIBLE);
                btnLocation.setVisibility(View.INVISIBLE);
                break;
        }
    }

    public class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter {
        public ScreenSlidePagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            if (position == 0) {
                return forecastFragment;
            } else if (position == 1) {
                districtFragment.set(mPager);
                return districtFragment;
            } else {
                mapFragment.set(mPager);
                return mapFragment;
            }
        }

        @Override
        public int getCount() {
            return NUM_PAGES;
        }

    }

}
