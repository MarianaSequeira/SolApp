package ua.pt.solapp.di.module;


import dagger.Module;
import dagger.android.ContributesAndroidInjector;
import ua.pt.solapp.fragments.UserProfileFragment;

/**
 * Created by Philippe on 02/03/2018.
 */

@Module
public abstract class FragmentModule {


    @ContributesAndroidInjector
    abstract UserProfileFragment contributeUserProfileFragment();


}
