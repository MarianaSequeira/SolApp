package ua.pt.solapp.fragments;


import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.support.AndroidSupportInjection;
import ua.pt.solapp.R;
import ua.pt.solapp.database.entities.DistrictID;
import ua.pt.solapp.database.entities.WeatherForecast;
import ua.pt.solapp.database.entities.WeatherID;
import ua.pt.solapp.database.entities.WindSpeed;
import ua.pt.solapp.view_models.DistrictIDViewModel;
import ua.pt.solapp.view_models.WeatherForecastViewModel;
import ua.pt.solapp.view_models.WeatherIDViewModel;
import ua.pt.solapp.view_models.WindSpeedViewModel;

/**
 * A simple {@link Fragment} subclass.
 */
public class UserProfileFragment extends Fragment {

    // FOR DATA
    public static final String UID_KEY = "uid";
    @Inject
    ViewModelProvider.Factory viewModelFactory;
    private WeatherForecastViewModel WFviewModel;
    private DistrictIDViewModel DDviewModel;
    private WeatherIDViewModel WDviewModel;
    private WindSpeedViewModel WSviewModel;

    // FOR DESIGN
    @BindView(R.id.fragment_user_profile_image)
    ImageView imageView;
    @BindView(R.id.fragment_user_profile_username)
    TextView username;
    @BindView(R.id.fragment_user_profile_company)
    TextView company;
    @BindView(R.id.fragment_user_profile_website)
    TextView website;
    @BindView(R.id.districtID)
    TextView districtID;
    @BindView(R.id.weatherID)
    TextView weatherID;
    @BindView(R.id.windSpeed)
    TextView windSpeed;


    public UserProfileFragment() { }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_user_profile, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.configureDagger();
        this.configureViewModel();
    }

    // -----------------
    // CONFIGURATION
    // -----------------

    private void configureDagger(){
        AndroidSupportInjection.inject(this);
    }

    private void configureViewModel(){
        int globalIdLocal = Integer.parseInt(getArguments().getString(UID_KEY));
        Log.d("yyy","HEYYYYYYYYYYYYYYYYYYYYY"+globalIdLocal);
        WFviewModel = ViewModelProviders.of(this, viewModelFactory).get(WeatherForecastViewModel.class);
        WFviewModel.init(globalIdLocal);
        WFviewModel.getWeatherForecast().observe(this, weatherForecast -> updateUI(weatherForecast));

        DDviewModel = ViewModelProviders.of(this, viewModelFactory).get(DistrictIDViewModel.class);
        DDviewModel.init();
        DDviewModel.getDistrictID().observe(this, districtID -> getDistrictID(districtID));

        WDviewModel = ViewModelProviders.of(this, viewModelFactory).get(WeatherIDViewModel.class);
        WDviewModel.init();
        WDviewModel.getWeatherID().observe(this, weatherID -> getWeatherID(weatherID));

        WSviewModel = ViewModelProviders.of(this, viewModelFactory).get(WindSpeedViewModel.class);
        WSviewModel.init();
        WSviewModel.getWindSpeed().observe(this, windSpeed -> getWindSpeed(windSpeed));
    }

    // -----------------
    // UPDATE UI
    // -----------------

    private void updateUI(@Nullable WeatherForecast weatherForecast){
        if (weatherForecast != null){
            this.username.setText(weatherForecast.getData().get(0).getTempMax().toString());
            this.company.setText(weatherForecast.getData().get(0).getClassWindSpeed()+"");
            this.website.setText(weatherForecast.getData().get(0).getIdWeatherType()+"");
        }
    }

    private void getDistrictID(@Nullable DistrictID districtID){
        if (districtID != null){
            this.districtID.setText(districtID.getData().get(0).getGlobalIdLocal()+"");
        }
    }

    private void getWeatherID(@Nullable WeatherID weatherID){
        if (weatherID != null){
            this.weatherID.setText(weatherID.getData().get(2).getDescIdWeatherTypePT()+"");
        }
    }

    private void getWindSpeed(@Nullable WindSpeed windSpeed){
        if (windSpeed != null){
            this.windSpeed.setText(windSpeed.getData().get(2).getDescClassWindSpeedDailyPT()+"");
        }
    }
}
