package ua.pt.solapp.view_models;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.ViewModel;

import javax.inject.Inject;

import ua.pt.solapp.database.entities.WeatherForecast;
import ua.pt.solapp.repositories.WeatherForecastRepository;

public class WeatherForecastViewModel extends ViewModel {

    private LiveData<WeatherForecast> weatherForecast;
    private WeatherForecastRepository weatherForecastRepository;

    @Inject
    public WeatherForecastViewModel(WeatherForecastRepository weatherIDRepository) {
        this.weatherForecastRepository = weatherIDRepository;
    }

    // ----

    public void init(int weatherForecastI) {
        if (this.weatherForecast != null) {
            return;
        }
        weatherForecast = weatherForecastRepository.getWeatherForecast(weatherForecastI);
    }

    public LiveData<WeatherForecast> getWeatherForecast() {
        return this.weatherForecast;
    }

}

