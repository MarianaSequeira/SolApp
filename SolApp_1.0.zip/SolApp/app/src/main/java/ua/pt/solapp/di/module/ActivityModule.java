package ua.pt.solapp.di.module;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;
import ua.pt.solapp.activities.MainActivity;

/**
 * Created by Philippe on 02/03/2018.
 */

@Module
public abstract class ActivityModule {
    @ContributesAndroidInjector(modules = FragmentModule.class)
    abstract MainActivity contributeMainActivity();
}
