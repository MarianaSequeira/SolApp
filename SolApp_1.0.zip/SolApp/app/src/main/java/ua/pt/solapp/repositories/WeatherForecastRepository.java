package ua.pt.solapp.repositories;

import android.arch.lifecycle.LiveData;
import android.util.Log;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Executor;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import ua.pt.solapp.App;
import ua.pt.solapp.api.WeatherWebService;
import ua.pt.solapp.database.dao.WeatherForecastDao;
import ua.pt.solapp.database.entities.WeatherForecast;

public class WeatherForecastRepository {

    private static int FRESH_TIMEOUT_IN_MINUTES = 1;

    private final WeatherWebService webservice;
    private final WeatherForecastDao weatherForecastDao;
    private final Executor executor;

    public WeatherForecastRepository(WeatherWebService webservice, WeatherForecastDao weatherForecastDao, Executor executor) {
        this.webservice = webservice;
        this.weatherForecastDao = weatherForecastDao;
        this.executor = executor;
    }

    // ---

    public LiveData<WeatherForecast> getWeatherForecast(int globalIdLocal) {
        getWeatherForecastValue(globalIdLocal); // try to refresh data if possible from Github Api
        return weatherForecastDao.getWeatherForecastFromGlobalId(globalIdLocal); // return a LiveData directly from the database.
    }

    // ---

    private void getWeatherForecastValue(final int globalIdLocal) {
        executor.execute(() -> {
            // Check if user was fetched recently

            boolean userExists = (weatherForecastDao.hasWeatherForecastFromGlobalId(globalIdLocal, getMaxRefreshTime(new Date())) != null);


            // If user have to be updated
            if (!userExists) {
                Log.d("IMPORTANT", "AQUIIIIIIIIIIIIIIIIIIII");
                webservice.getWeatherForecast(globalIdLocal).enqueue(new Callback<WeatherForecast>() {
                    @Override
                    public void onResponse(Call<WeatherForecast> call, Response<WeatherForecast> response) {
                        Log.e("TAG", "DATA REFRESHED FROM NETWORK");
                        Toast.makeText(App.context, "Data refreshed from network !", Toast.LENGTH_LONG).show();

                        executor.execute(() -> {
                            WeatherForecast wf = response.body();
                            wf.setLastRefresh(new Date());

                            Log.d("IMPORTANT", response+" "+wf.toString());

                            weatherForecastDao.saveWeatherForecast(wf);
                        });
                    }

                    @Override
                    public void onFailure(Call<WeatherForecast> call, Throwable t) { }
                });
            }
        });
    }

    // ---

    private Date getMaxRefreshTime(Date currentDate){
        Calendar cal = Calendar.getInstance();
        cal.setTime(currentDate);
        cal.add(Calendar.MINUTE, -FRESH_TIMEOUT_IN_MINUTES);
        return cal.getTime();
    }
}
